create
    definer = root@localhost function user_exists(email varchar(20)) returns tinyint(1)
begin
    return (
        exists(select User from mysql.user where User=email)
    );
end;

