create
    definer = root@localhost procedure PharmacyRecords(IN drug varchar(45))
begin
    select * from VendorDrugInfo where drugName = drug;    
end;

