create definer = root@localhost view nurseinfo as
(
select `n`.`nurseID`       AS `nurseID`,
       `n`.`qualification` AS `qualification`,
       `n`.`license`       AS `license`,
       `e`.`name`          AS `name`,
       `e`.`phone`         AS `phone`,
       `e`.`email`         AS `email`,
       `e`.`address`       AS `address`,
       `e`.`sex`           AS `sex`
from (`hyacinth`.`nurse` `n`
         join `hyacinth`.`employee` `e` on (`n`.`nurseID` = `e`.`employeeID`)));

grant select on table nurseinfo to patient_role@'''''';

