create
    definer = root@localhost procedure PatientProfile(IN ID int)
begin
    select * from PatientInfo where patientID = ID;    
end;

