create
    definer = root@localhost procedure DriverProfile(IN ID int)
begin
    select * from DriverInfo where driverID = ID;    
end;

