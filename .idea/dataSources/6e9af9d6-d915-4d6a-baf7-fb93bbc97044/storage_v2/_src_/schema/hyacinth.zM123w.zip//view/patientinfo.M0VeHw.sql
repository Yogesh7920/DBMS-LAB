create definer = root@localhost view patientinfo as
(
select `hyacinth`.`patient`.`patientID`      AS `patientID`,
       `hyacinth`.`patient`.`name`           AS `patientName`,
       `hyacinth`.`patient`.`phone`          AS `phone`,
       `hyacinth`.`patient`.`email`          AS `email`,
       `hyacinth`.`patient`.`address`        AS `address`,
       `hyacinth`.`patient`.`sex`            AS `sex`,
       `hyacinth`.`patient`.`medicalHistory` AS `medicalHistory`,
       `hyacinth`.`patient`.`marital`        AS `marital`
from `hyacinth`.`patient`);

