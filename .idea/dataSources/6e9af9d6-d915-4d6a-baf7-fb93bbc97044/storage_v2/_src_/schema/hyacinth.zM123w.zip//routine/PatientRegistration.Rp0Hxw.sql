create
    definer = root@localhost procedure PatientRegistration(IN name_ varchar(45), IN email_ varchar(20),
                                                           IN password_ varchar(255), IN phone varchar(20),
                                                           IN address_ varchar(20), IN sex varchar(20),
                                                           IN medicalHistory varchar(300), IN marital tinyint(1),
                                                           OUT registered tinyint(1))
begin
    if user_exists(email_)
    then
        set registered=false;
    else
        set @create_user = concat('create user \'', substring_index(email_, '@', 1), '\'@\'localhost\' identified by \'', password_, '\';');
        call exec_query(@create_user);
        set @insert_user = concat(
            'insert into Patient set',
            ' name = \'', name_, '\'',
            ', email = \'', email_, '\'',
            ', phone = \'', phone, '\'',
            ', password = \'', PASSWORD(password_), '\'',
            ', address = \'', address_, '\'',
            ', sex = \'', sex, '\'',
            ', medicalHistory = \'', medicalHistory, '\'',
            ', marital = ', marital
        );
        select @insert_user;
        call exec_query(@insert_user);
        grant patient_role to email;
        set registered=true;
    end if;
end;

