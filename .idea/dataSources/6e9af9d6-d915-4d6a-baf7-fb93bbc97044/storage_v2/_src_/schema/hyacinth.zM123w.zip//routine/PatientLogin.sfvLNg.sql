create
    definer = root@localhost procedure PatientLogin(IN email_ varchar(20), IN password_ varchar(255),
                                                    OUT valid tinyint(1))
begin
    if user_exists(email_)
    then
        set @password = (select password from patient where email=email_);
        if (password(password_)=@password) then
            set valid=true;
        end if;
    else
        set valid=false;
    end if;
end;

