create
    definer = root@localhost procedure HospitalRecords(IN ID int)
begin
    select * from PatientDoctorInfo where patientID = ID;    
end;

