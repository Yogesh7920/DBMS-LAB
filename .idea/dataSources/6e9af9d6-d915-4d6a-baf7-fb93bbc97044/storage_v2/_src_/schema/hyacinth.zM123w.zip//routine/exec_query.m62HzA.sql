create
    definer = root@localhost procedure exec_query(IN query_str varchar(255))
begin
    set @exec_cmd = query_str;
    prepare stmt from @exec_cmd;
    execute stmt;
    deallocate prepare stmt;
end;

