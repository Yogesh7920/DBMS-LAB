create
    definer = root@localhost procedure DiagnosticsHistory(IN ID int, IN cat varchar(20))
begin
    select * from NurseDiagnosticsInfo where nurseID = ID and category = cat;    
end;

