create definer = root@localhost view patientdoctorinfo as
(
select `d`.`pharmacyID`               AS `pharmacyID`,
       `a`.`prescriptionId`           AS `prescriptionId`,
       `a`.`invoiceId`                AS `invoiceId`,
       `c`.`consultationID`           AS `consultationID`,
       `patientinfo`.`patientID`      AS `patientID`,
       `patientinfo`.`patientName`    AS `patientName`,
       `patientinfo`.`phone`          AS `phone`,
       `patientinfo`.`email`          AS `email`,
       `patientinfo`.`address`        AS `address`,
       `patientinfo`.`sex`            AS `sex`,
       `patientinfo`.`medicalHistory` AS `medicalHistory`,
       `patientinfo`.`marital`        AS `marital`,
       `c`.`problem`                  AS `problem`,
       `c`.`doctorID`                 AS `doctorID`,
       `a`.`appointmentID`            AS `appointmentID`,
       `a`.`startTime`                AS `startTime`,
       `a`.`endTime`                  AS `endTime`,
       `a`.`remarks`                  AS `remarks`,
       `i`.`amount`                   AS `amount`,
       `i`.`isPaid`                   AS `isPaid`,
       `p`.`timeStamp`                AS `timeStamp`,
       `ph`.`name`                    AS `name`,
       `ph`.`category`                AS `category`
from ((((((`hyacinth`.`patientinfo` join `hyacinth`.`consultation` `c` on (`patientinfo`.`patientID` = `c`.`patientID`)) join `hyacinth`.`appointment` `a` on (`c`.`consultationID` = `a`.`consultationId`)) join `hyacinth`.`invoice` `i` on (`a`.`invoiceId` = `i`.`invoiceID`)) join `hyacinth`.`prescription` `p` on (`a`.`prescriptionId` = `p`.`prescriptionID`)) join `hyacinth`.`drugs` `d` on (`a`.`prescriptionId` = `d`.`prescriptionID`))
         join `hyacinth`.`pharmacy` `ph` on (`d`.`pharmacyID` = `ph`.`pharmacyID`)));

