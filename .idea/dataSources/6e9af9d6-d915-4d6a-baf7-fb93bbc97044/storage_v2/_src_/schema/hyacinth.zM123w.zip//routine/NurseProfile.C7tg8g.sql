create
    definer = root@localhost procedure NurseProfile(IN ID int)
begin
    select * from NurseInfo where nurseID = ID;    
end;

