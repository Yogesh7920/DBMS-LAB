create
    definer = root@localhost procedure PatientRecords(IN ID int)
begin
    select * from DoctorPatientInfo where doctorID = ID;    
end;

