create
    definer = root@localhost procedure EmployeeRegistration(IN email_ varchar(20), IN password_ varchar(255),
                                                            OUT role varchar(11))
begin
    -- If user exists, then check password
    if user_exists(email_)
    then
        set @password = (select password from Employee where email=email_);
        if (password(password_)=@password) then
            set role=employee_role(email_);
        else
            set role='None';
        end if;
    -- If user does not exist, check if the admin has added him/her as an employee.
    elseif exists(select * from Employee where email=email_)
    then
        set @create_user = concat('create user \'', substring_index(email_, '@', 1), '\'@\'localhost\' identified by \'', password_, '\';');
        call exec_query(@create_user);
        set role=employee_role(email_);
    -- If the admin has not added the Employee, don't allow registration.
    else
        set role='None';
    end if;
end;

