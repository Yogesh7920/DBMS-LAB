create definer = root@localhost view doctorinfo as
(
select `d`.`doctorID`       AS `doctorID`,
       `d`.`qualification`  AS `qualification`,
       `d`.`license`        AS `license`,
       `d`.`bio`            AS `bio`,
       `d`.`available`      AS `available`,
       `d`.`specialization` AS `specialization`,
       `e`.`name`           AS `doctorName`,
       `e`.`phone`          AS `phone`,
       `e`.`email`          AS `email`,
       `e`.`address`        AS `address`,
       `e`.`sex`            AS `sex`
from (`hyacinth`.`doctor` `d`
         join `hyacinth`.`employee` `e` on (`d`.`doctorID` = `e`.`employeeID`)));

grant select on table doctorinfo to patient_role@'''''';

