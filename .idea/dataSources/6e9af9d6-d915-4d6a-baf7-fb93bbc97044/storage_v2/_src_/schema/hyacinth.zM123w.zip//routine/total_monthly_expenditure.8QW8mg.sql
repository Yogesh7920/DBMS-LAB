create
    definer = root@localhost function total_monthly_expenditure() returns float
begin
    return (
        select sum(price), temp.total from Hyacinth.Supplies, (
              select sum(salary) as total from employee
            ) as temp
        where (orderTime > date_sub(curdate(), interval dayofmonth(curdate()) - 1 day ))
    );
end;

