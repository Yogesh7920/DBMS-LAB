create definer = root@localhost view driverinfo as
(
select `d`.`driverID` AS `driverID`,
       `e`.`name`     AS `name`,
       `e`.`phone`    AS `phone`,
       `e`.`email`    AS `email`,
       `e`.`address`  AS `address`,
       `e`.`sex`      AS `sex`
from (`hyacinth`.`driver` `d`
         join `hyacinth`.`employee` `e` on (`d`.`driverID` = `e`.`employeeID`)));

