create definer = root@localhost view patientconsultinfo as
(
select `hyacinth`.`consultation`.`patientID`      AS `patientID`,
       `hyacinth`.`consultation`.`doctorID`       AS `doctorID`,
       `hyacinth`.`consultation`.`consultationID` AS `consultationID`,
       `hyacinth`.`consultation`.`problem`        AS `problem`,
       `hyacinth`.`doctor`.`specialization`       AS `specialization`
from (`hyacinth`.`consultation`
         join `hyacinth`.`doctor` on (`hyacinth`.`consultation`.`doctorID` = `hyacinth`.`doctor`.`doctorID`)));

