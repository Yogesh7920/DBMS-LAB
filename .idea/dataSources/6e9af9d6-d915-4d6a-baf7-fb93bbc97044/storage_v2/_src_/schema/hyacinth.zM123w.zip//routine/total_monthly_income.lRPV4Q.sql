create
    definer = root@localhost function total_monthly_income() returns float
begin
    return (
        select sum(amount) from Hyacinth.Invoice
        inner join Appointment a on Invoice.invoiceID = a.invoiceId
        where (isPaid=1) and (startTime > date_sub(curdate(), interval dayofmonth(curdate()) - 1 day ))
    );
end;

