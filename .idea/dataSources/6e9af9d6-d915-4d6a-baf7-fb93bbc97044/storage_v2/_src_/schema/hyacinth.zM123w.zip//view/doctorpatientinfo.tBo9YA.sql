create definer = root@localhost view doctorpatientinfo as
(
select `d`.`pharmacyID`          AS `pharmacyID`,
       `a`.`prescriptionId`      AS `prescriptionId`,
       `c`.`consultationID`      AS `consultationID`,
       `doctorinfo`.`doctorID`   AS `doctorID`,
       `doctorinfo`.`doctorName` AS `doctorName`,
       `doctorinfo`.`phone`      AS `phone`,
       `doctorinfo`.`email`      AS `email`,
       `doctorinfo`.`address`    AS `address`,
       `doctorinfo`.`sex`        AS `sex`,
       `c`.`problem`             AS `problem`,
       `c`.`patientID`           AS `patientID`,
       `a`.`appointmentID`       AS `appointmentID`,
       `a`.`startTime`           AS `startTime`,
       `a`.`endTime`             AS `endTime`,
       `a`.`remarks`             AS `remarks`,
       `a`.`invoiceId`           AS `invoiceId`,
       `pr`.`timeStamp`          AS `timeStamp`,
       `ph`.`name`               AS `name`,
       `ph`.`category`           AS `category`
from (((((`hyacinth`.`doctorinfo` join `hyacinth`.`consultation` `c` on (`doctorinfo`.`doctorID` = `c`.`doctorID`)) join `hyacinth`.`appointment` `a` on (`c`.`consultationID` = `a`.`consultationId`)) join `hyacinth`.`prescription` `pr` on (`a`.`prescriptionId` = `pr`.`prescriptionID`)) join `hyacinth`.`drugs` `d` on (`a`.`prescriptionId` = `d`.`prescriptionID`))
         join `hyacinth`.`pharmacy` `ph` on (`d`.`pharmacyID` = `ph`.`pharmacyID`)));

