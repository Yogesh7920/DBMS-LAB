create
    definer = root@localhost procedure AdminProfile(IN ID int)
begin
    select * from AdminInfo where adminID = ID;    
end;

