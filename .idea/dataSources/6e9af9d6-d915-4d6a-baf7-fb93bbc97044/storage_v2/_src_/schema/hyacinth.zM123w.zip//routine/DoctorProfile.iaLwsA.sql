create
    definer = root@localhost procedure DoctorProfile(IN ID int)
begin
    select * from DoctorInfo where doctorID = ID;    
end;

