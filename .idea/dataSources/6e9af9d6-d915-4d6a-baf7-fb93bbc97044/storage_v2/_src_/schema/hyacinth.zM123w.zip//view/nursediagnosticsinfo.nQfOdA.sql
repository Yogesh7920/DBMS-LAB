create definer = root@localhost view nursediagnosticsinfo as
(
select `nurseinfo`.`nurseID`                    AS `nurseID`,
       `nurseinfo`.`qualification`              AS `qualification`,
       `nurseinfo`.`license`                    AS `license`,
       `nurseinfo`.`name`                       AS `name`,
       `nurseinfo`.`phone`                      AS `phone`,
       `nurseinfo`.`email`                      AS `email`,
       `nurseinfo`.`address`                    AS `address`,
       `nurseinfo`.`sex`                        AS `sex`,
       `hyacinth`.`diagnostics`.`diagnosticsID` AS `diagnosticsID`,
       `hyacinth`.`diagnostics`.`category`      AS `category`,
       `hyacinth`.`diagnostics`.`name`          AS `diagnostics`
from ((`hyacinth`.`nurseinfo` join `hyacinth`.`assists` on (`nurseinfo`.`nurseID` = `hyacinth`.`assists`.`nurseId`))
         join `hyacinth`.`diagnostics`
              on (`hyacinth`.`assists`.`diagnosticsID` = `hyacinth`.`diagnostics`.`diagnosticsID`)));

