create definer = root@localhost view driverjourneyinfo as
(
select `driverinfo`.`driverID`                  AS `driverID`,
       `driverinfo`.`name`                      AS `name`,
       `driverinfo`.`phone`                     AS `phone`,
       `driverinfo`.`email`                     AS `email`,
       `driverinfo`.`address`                   AS `address`,
       `driverinfo`.`sex`                       AS `sex`,
       `hyacinth`.`ambulance`.`ambulanceID`     AS `ambulanceID`,
       `hyacinth`.`ambulance`.`lastMaintenance` AS `lastMaintenance`,
       `hyacinth`.`ambulance`.`totalDistance`   AS `totalDistance`,
       `hyacinth`.`journey`.`startTime`         AS `startTime`,
       `hyacinth`.`journey`.`endTime`           AS `endTime`,
       `hyacinth`.`journey`.`address`           AS `journeyAddress`
from ((`hyacinth`.`driverinfo` join `hyacinth`.`journey` on (`driverinfo`.`driverID` = `hyacinth`.`journey`.`driverID`))
         join `hyacinth`.`ambulance` on (`hyacinth`.`journey`.`ambulanceId` = `hyacinth`.`ambulance`.`ambulanceID`)));

