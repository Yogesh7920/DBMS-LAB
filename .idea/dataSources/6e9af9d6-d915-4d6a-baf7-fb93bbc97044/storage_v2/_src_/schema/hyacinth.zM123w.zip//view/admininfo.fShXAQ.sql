create definer = root@localhost view admininfo as
(
select `a`.`adminID` AS `adminID`,
       `e`.`name`    AS `name`,
       `e`.`phone`   AS `phone`,
       `e`.`email`   AS `email`,
       `e`.`address` AS `address`,
       `e`.`sex`     AS `sex`
from (`hyacinth`.`admin` `a`
         join `hyacinth`.`employee` `e` on (`a`.`adminID` = `e`.`employeeID`)));

