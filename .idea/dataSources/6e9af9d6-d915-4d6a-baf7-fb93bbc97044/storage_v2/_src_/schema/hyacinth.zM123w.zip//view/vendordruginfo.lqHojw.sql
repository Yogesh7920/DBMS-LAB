create definer = root@localhost view vendordruginfo as
(
select `hyacinth`.`vendor`.`vendorID` AS `vendorID`,
       `p`.`pharmacyID`               AS `pharmacyID`,
       `hyacinth`.`vendor`.`name`     AS `name`,
       `hyacinth`.`vendor`.`phone`    AS `phone`,
       `hyacinth`.`vendor`.`address`  AS `address`,
       `hyacinth`.`vendor`.`email`    AS `email`,
       `s`.`price`                    AS `price`,
       `s`.`orderTime`                AS `orderTime`,
       `s`.`supplyTime`               AS `supplyTime`,
       `p`.`name`                     AS `drugName`,
       `p`.`category`                 AS `category`
from ((`hyacinth`.`vendor` join `hyacinth`.`supplies` `s` on (`hyacinth`.`vendor`.`vendorID` = `s`.`vendorID`))
         join `hyacinth`.`pharmacy` `p` on (`s`.`pharmacyID` = `p`.`pharmacyID`)));

