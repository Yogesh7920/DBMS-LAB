create
    definer = root@localhost procedure DriveRecords(IN ID int)
begin
    select * from DriverJourneyInfo where driverID = ID;    
end;

