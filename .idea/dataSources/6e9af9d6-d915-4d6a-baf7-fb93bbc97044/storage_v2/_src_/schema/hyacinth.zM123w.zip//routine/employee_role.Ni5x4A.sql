create
    definer = root@localhost function employee_role(email_ varchar(20)) returns varchar(20)
begin
    if exists(
        select * from Doctor
        where doctorID=(select employeeID from Employee where email=email_)
    )
    then
        return 'Doctor';
    elseif exists(
        select * from Nurse
        where nurseID=(select employeeID from Employee where email=email_)
    )
    then return 'Nurse';
    elseif exists(
        select * from Driver
        where driverID=(select employeeID from Employee where email=email_)
    )
    then return 'Driver';
    elseif exists(
        select * from Admin
        where adminID=(select employeeID from Employee where email=email_)
    )
    then return 'Admin';
    else return 'Invalid';
    end if;
end;

